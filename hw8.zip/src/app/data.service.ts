import { Injectable } from '@angular/core';

@Injectable()
export class Data {

    public results: any;

    public constructor() { }

}