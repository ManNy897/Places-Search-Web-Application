import { Component, Input } from '@angular/core';

@Component({
  selector: 'blank-component',
  template: '<div></div>'  
})
export class BlankComponent {
}